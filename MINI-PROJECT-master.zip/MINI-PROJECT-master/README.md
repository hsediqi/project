# PHP MySQL User Signup Login API

Find Step by Step Tutorial here http://codinginfinite.com/restful-api-using-php-mysql-best-practice/
This step by step tutorial will guide you to setup up Login + Signup API using Core PHP + MySQL following best practices with folders structure
